Files:
- "uk12_name.csv": names of the cities
- "uk12_xy.csv": (x,y) coordinates of the cities

The shortest path is:
Aberystwyth -> Inverness -> Nottingham -> Glasgow -> Edinburgh -> London -> Stratford -> Exeter -> Liverpool -> Oxford -> Brighton -> Newcastle

Reversed path is:
Newcastle -> Brighton -> Oxford -> Liverpool -> Exeter -> Stratford -> London -> Edinburgh -> Glasgow -> Nottingham -> Inverness -> Aberystwyth

The total distance is:
1595.738522033024


|Aberystwyth         |Newcastle           |
|Inverness           |Brighton            |
|Nottingham          |Oxford              |
|Glasgow             |Liverpool           |
|Edinburgh           |Exeter              |
|London              |Stratford           |
|Stratford           |London              |
|Exeter              |Edinburgh           |
|Liverpool           |Glasgow             |
|Oxford              |Nottingham          |
|Brighton            |Inverness           |
|Newcastle           |Aberystwyth         |
|1595.738522033024   |1595.738522033024   |